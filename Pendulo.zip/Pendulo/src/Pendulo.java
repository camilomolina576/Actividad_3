import java.util.Scanner;

public class Pendulo {
	public static double longitud;
	public static double acceleracion = 9.8;
	
	public static double result() {
		return (2 * Math.PI) * Math.sqrt((acceleracion/longitud)); 
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Escribe la longitud: ");
		longitud = input.nextDouble();
		input.close();
		
		System.out.println("Result: " + result());
	}
}
