import java.util.Scanner;

public class Ascensor {
	public static int numeroPisos, currentPiso = 1, sotanos;
	
	public int changeUpFloor(int deltaFloor) {
		return currentPiso + deltaFloor;
	}
	
	public int changeDownFloor(int deltaFloor) {
		return currentPiso - deltaFloor;
	}
	
	public static int pisosAttendidos(int sotanos, int numeroPisos) {
		return sotanos + numeroPisos;
	}
	
	public int getPiso() {
		return currentPiso;
	}
	
	public static void main(String[] args) {
		System.out.println("Por favor entre el numero de sotanos: ");
		Scanner input = new Scanner(System.in);
		sotanos = input.nextInt();
		System.out.println("Enter the number of pisos: ");
		numeroPisos = input.nextInt();
		
		System.out.println("El numero de pisos que este ancensor puede atendir es: " + pisosAttendidos(sotanos, numeroPisos));
		input.close();
	}
}
