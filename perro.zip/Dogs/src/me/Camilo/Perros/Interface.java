package me.Camilo.Perros;

import java.util.ArrayList;

public class Interface {
	public static void main(String[] args) {
		ArrayList<String> dogs = new ArrayList<String>();
		
	}
}
